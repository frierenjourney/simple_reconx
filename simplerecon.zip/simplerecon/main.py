import sys
from datetime import datetime

# import all our tools
from tools.whois_scan     import run_whois
from tools.host_scan      import run_host
from tools.dig_scan       import run_dig
from tools.dnsrecon_scan  import run_dnsrecon
from tools.sublist3r_scan import run_sublist3r
from tools.harvester_scan import run_harvester
from tools.nmap_scan      import run_nmap


# ── check domain was given ────────────────────────────────────
if len(sys.argv) < 2:
    print("Usage: python3 main.py <domain>")
    print("Example: python3 main.py scanme.nmap.org")
    sys.exit(1)

domain = sys.argv[1].strip()

print(f"""
╔══════════════════════════════════════╗
║         SIMPLE RECON TOOL           ║
║         by frierenjourney           ║
╚══════════════════════════════════════╝
  Target  : {domain}
  Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
""")


# ── run all tools one by one ─────────────────────────────────

print("\n--- STEP 1/7 : WHOIS ---")
whois = run_whois(domain)

print("\n--- STEP 2/7 : HOST ---")
host_ips = run_host(domain)

print("\n--- STEP 3/7 : DIG ---")
dig = run_dig(domain)

print("\n--- STEP 4/7 : DNSRECON ---")
dnsrecon = run_dnsrecon(domain)

print("\n--- STEP 5/7 : SUBLIST3R ---")
subdomains = run_sublist3r(domain)

print("\n--- STEP 6/7 : THEHARVESTER ---")
harvester = run_harvester(domain)

print("\n--- STEP 7/7 : NMAP ---")
ports = run_nmap(domain)


# ── combine subdomains and ips from all tools ─────────────────

all_subdomains = sorted(set(subdomains + harvester["subdomains"]))
all_ipv4       = sorted(set(host_ips + dig["ipv4"] + harvester["ips"]))
all_ipv6       = sorted(set(dig["ipv6"]))
all_emails     = sorted(set(harvester["emails"]))
all_people     = sorted(set(harvester["people"]))
all_mx         = sorted(set(dig["mx"]))
all_ns         = sorted(set(dig["ns"]))


# ── print final report ────────────────────────────────────────

print(f"""
╔══════════════════════════════════════╗
║           FINAL REPORT              ║
╚══════════════════════════════════════╝
  Target : {domain}
""")

print("[WHOIS]")
print(f"  Registrar : {whois['registrar'] or 'N/A'}")
print(f"  Owner     : {whois['owner'] or 'N/A'}")
print(f"  Country   : {whois['country'] or 'N/A'}")
print(f"  Created   : {whois['created'] or 'N/A'}")
print(f"  Expires   : {whois['expires'] or 'N/A'}")
for ns in whois["nameservers"]:
    print(f"  NS        : {ns}")

print(f"\n[SUBDOMAINS] — {len(all_subdomains)} found")
for s in all_subdomains:
    print(f"  → {s}")

print(f"\n[IPv4] — {len(all_ipv4)} found")
for ip in all_ipv4:
    print(f"  → {ip}")

print(f"\n[IPv6] — {len(all_ipv6)} found")
for ip in all_ipv6:
    print(f"  → {ip}")

print(f"\n[MX RECORDS] — {len(all_mx)} found")
for mx in all_mx:
    print(f"  → {mx}")

print(f"\n[NS RECORDS] — {len(all_ns)} found")
for ns in all_ns:
    print(f"  → {ns}")

print(f"\n[EMAILS] — {len(all_emails)} found")
for e in all_emails:
    print(f"  → {e}")

print(f"\n[PEOPLE] — {len(all_people)} found")
for p in all_people:
    print(f"  → {p}")

print(f"\n[ZONE TRANSFER]")
if dnsrecon["zone_transfer"]:
    print("  → [!!] SUCCESSFUL — full DNS map exposed!")
else:
    print("  → Failed (server is protected — normal)")

print(f"\n[OPEN PORTS] — {len(ports)} found")
for p in ports:
    print(f"  {p['port']}/tcp  →  {p['service']}  {p['version']}")


# ── save report to .txt file ──────────────────────────────────

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename  = f"{domain}_{timestamp}.txt"

with open(filename, "w") as f:
    f.write(f"RECON REPORT — {domain}\n")
    f.write(f"Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write("=" * 45 + "\n\n")

    f.write("[WHOIS]\n")
    f.write(f"  Registrar : {whois['registrar'] or 'N/A'}\n")
    f.write(f"  Owner     : {whois['owner'] or 'N/A'}\n")
    f.write(f"  Country   : {whois['country'] or 'N/A'}\n")
    f.write(f"  Created   : {whois['created'] or 'N/A'}\n")
    f.write(f"  Expires   : {whois['expires'] or 'N/A'}\n")
    for ns in whois["nameservers"]:
        f.write(f"  NS        : {ns}\n")

    f.write(f"\n[SUBDOMAINS] — {len(all_subdomains)} found\n")
    for s in all_subdomains:
        f.write(f"  → {s}\n")

    f.write(f"\n[IPv4] — {len(all_ipv4)} found\n")
    for ip in all_ipv4:
        f.write(f"  → {ip}\n")

    f.write(f"\n[IPv6] — {len(all_ipv6)} found\n")
    for ip in all_ipv6:
        f.write(f"  → {ip}\n")

    f.write(f"\n[MX RECORDS] — {len(all_mx)} found\n")
    for mx in all_mx:
        f.write(f"  → {mx}\n")

    f.write(f"\n[NS RECORDS] — {len(all_ns)} found\n")
    for ns in all_ns:
        f.write(f"  → {ns}\n")

    f.write(f"\n[EMAILS] — {len(all_emails)} found\n")
    for e in all_emails:
        f.write(f"  → {e}\n")

    f.write(f"\n[PEOPLE] — {len(all_people)} found\n")
    for p in all_people:
        f.write(f"  → {p}\n")

    f.write(f"\n[ZONE TRANSFER]\n")
    if dnsrecon["zone_transfer"]:
        f.write("  → SUCCESSFUL!\n")
    else:
        f.write("  → Failed\n")

    f.write(f"\n[OPEN PORTS] — {len(ports)} found\n")
    for p in ports:
        f.write(f"  {p['port']}/tcp  →  {p['service']}  {p['version']}\n")

print(f"\n[+] Report saved → {filename}")
print(f"[*] Done.\n")
