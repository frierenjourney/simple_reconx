import subprocess

def run_dnsrecon(domain):
    print("[*] Running dnsrecon...")

    # standard dns scan
    output = subprocess.run(
        ["dnsrecon", "-d", domain, "-t", "std"],
        capture_output=True, text=True
    ).stdout

    # print the raw output — dnsrecon already formats it nicely
    print(output.strip())

    # try zone transfer — this is a big find if it works
    print("[*] Trying zone transfer (AXFR)...")
    zt_output = subprocess.run(
        ["dnsrecon", "-d", domain, "-t", "axfr"],
        capture_output=True, text=True
    ).stdout

    zone_transfer = False
    if "Zone Transfer was successful" in zt_output:
        print("  [!!] ZONE TRANSFER SUCCESSFUL!")
        zone_transfer = True
    else:
        print("  [-] Zone transfer failed (this is normal)")

    return {"zone_transfer": zone_transfer}
