import subprocess

def run_whois(domain):
    print("[*] Running whois...")

    # run the whois command
    output = subprocess.run(["whois", domain], capture_output=True, text=True).stdout

    # we will store results here
    result = {
        "registrar": "",
        "owner": "",
        "country": "",
        "created": "",
        "expires": "",
        "nameservers": []
    }

    # go through each line and pick what we need
    for line in output.splitlines():
        line = line.strip()

        if "Registrar:" in line and not result["registrar"]:
            result["registrar"] = line.split(":", 1)[1].strip()

        elif "Registrant Organization:" in line and not result["owner"]:
            result["owner"] = line.split(":", 1)[1].strip()

        elif "Registrant Country:" in line and not result["country"]:
            result["country"] = line.split(":", 1)[1].strip()

        elif ("Creation Date:" in line or "Created:" in line) and not result["created"]:
            result["created"] = line.split(":", 1)[1].strip()

        elif ("Expiry Date:" in line or "Expiration:" in line) and not result["expires"]:
            result["expires"] = line.split(":", 1)[1].strip()

        elif "Name Server:" in line:
            ns = line.split(":", 1)[1].strip().lower()
            if ns not in result["nameservers"]:
                result["nameservers"].append(ns)

    # print what we found
    print(f"  Registrar : {result['registrar'] or 'N/A'}")
    print(f"  Owner     : {result['owner'] or 'N/A'}")
    print(f"  Country   : {result['country'] or 'N/A'}")
    print(f"  Created   : {result['created'] or 'N/A'}")
    print(f"  Expires   : {result['expires'] or 'N/A'}")
    for ns in result["nameservers"]:
        print(f"  NS        : {ns}")

    return result
