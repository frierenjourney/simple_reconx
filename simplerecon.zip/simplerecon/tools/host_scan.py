import subprocess

def run_host(domain):
    print("[*] Running host...")

    # run the host command
    output = subprocess.run(["host", domain], capture_output=True, text=True).stdout

    ips = []

    # each line looks like: "google.com has address 142.250.80.46"
    for line in output.splitlines():
        if "has address" in line:
            ip = line.split("has address")[1].strip()
            if ip not in ips:
                ips.append(ip)

    print(f"  IPs found : {ips}")
    return ips
