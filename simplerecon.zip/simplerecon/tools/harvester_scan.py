import subprocess
import json
import os

def run_harvester(domain):
    print("[*] Running theHarvester...")

    outfile = "/tmp/harvester_out"

    # run theHarvester — searches public sources for emails, subdomains, ips
    subprocess.run(
        ["theHarvester", "-d", domain,
         "-b", "crtsh,duckduckgo,dnsdumpster,hackertarget",
         "-f", outfile],
        capture_output=True, text=True
    )

    result = {
        "subdomains": [],
        "emails": [],
        "ips": [],
        "people": []
    }

    # theHarvester saves a json file — we read it here
    jsonfile = outfile + ".json"
    if os.path.exists(jsonfile):
        with open(jsonfile) as f:
            data = json.load(f)

        for host in data.get("hosts", []):
            h = host.split(":")[0].strip()
            if domain in h and h not in result["subdomains"]:
                result["subdomains"].append(h)

        for email in data.get("emails", []):
            if email not in result["emails"]:
                result["emails"].append(email)

        for ip in data.get("ips", []):
            if ip not in result["ips"]:
                result["ips"].append(ip)

        for person in data.get("people", []):
            if person not in result["people"]:
                result["people"].append(person)
    else:
        print("  [-] No output file — theHarvester may not be installed")

    print(f"  Subdomains : {len(result['subdomains'])}")
    print(f"  Emails     : {len(result['emails'])}")
    print(f"  IPs        : {len(result['ips'])}")
    print(f"  People     : {len(result['people'])}")

    return result
