import subprocess

def run_dig(domain):
    print("[*] Running dig...")

    # we will store all dns records here
    result = {
        "ipv4": [],
        "ipv6": [],
        "mx":   [],
        "ns":   [],
        "txt":  []
    }

    # query each record type one by one
    for rtype in ["A", "AAAA", "MX", "NS", "TXT"]:

        output = subprocess.run(
            ["dig", domain, rtype, "+noall", "+answer"],
            capture_output=True, text=True
        ).stdout

        for line in output.splitlines():
            parts = line.split()
            if len(parts) < 5:
                continue

            # the answer is always the last part
            value = parts[-1].rstrip(".")

            if rtype == "A"    and value not in result["ipv4"]:
                result["ipv4"].append(value)
            elif rtype == "AAAA" and value not in result["ipv6"]:
                result["ipv6"].append(value)
            elif rtype == "MX"   and value not in result["mx"]:
                result["mx"].append(value)
            elif rtype == "NS"   and value not in result["ns"]:
                result["ns"].append(value)
            elif rtype == "TXT"  and value not in result["txt"]:
                result["txt"].append(value)

    print(f"  IPv4 : {result['ipv4']}")
    print(f"  IPv6 : {result['ipv6']}")
    print(f"  MX   : {result['mx']}")
    print(f"  NS   : {result['ns']}")

    return result
