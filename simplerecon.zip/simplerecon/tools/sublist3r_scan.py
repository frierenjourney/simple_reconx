import subprocess
import os

def run_sublist3r(domain):
    print("[*] Running sublist3r...")

    outfile = "/tmp/sublist3r_out.txt"

    # remove old output file if it exists
    if os.path.exists(outfile):
        os.remove(outfile)

    # run sublist3r and save results to a file
    subprocess.run(
        ["sublist3r", "-d", domain, "-o", outfile],
        capture_output=True, text=True
    )

    subdomains = []

    # read the output file line by line
    if os.path.exists(outfile):
        with open(outfile) as f:
            for line in f:
                line = line.strip()
                if domain in line and line not in subdomains:
                    subdomains.append(line)
        print(f"  Found {len(subdomains)} subdomains")
    else:
        print("  [-] No output file — sublist3r may not be installed")

    return subdomains
