import subprocess

def run_nmap(domain):
    print("[*] Running nmap...")

    # -sV  = detect service versions
    # --open = only show open ports
    # -T4  = faster scan speed
    output = subprocess.run(
        ["nmap", "-sV", "--open", "-T4", domain],
        capture_output=True, text=True
    ).stdout

    ports = []

    # each open port line looks like:
    # 80/tcp   open  http    Apache 2.4.49
    for line in output.splitlines():
        if "/tcp" in line and "open" in line:
            parts = line.split()
            port    = parts[0].split("/")[0]        # e.g. "80"
            service = parts[2] if len(parts) > 2 else "unknown"
            version = " ".join(parts[3:]) if len(parts) > 3 else "unknown"

            ports.append({
                "port": port,
                "service": service,
                "version": version
            })

    print(f"  Found {len(ports)} open ports")
    for p in ports:
        print(f"  {p['port']}/tcp  →  {p['service']}  {p['version']}")

    return ports
